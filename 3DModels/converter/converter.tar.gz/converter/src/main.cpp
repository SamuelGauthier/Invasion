#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <string.h>
using namespace std;

struct Vec3f 
{
	float x,y,z;
	Vec3f(float _x=0.f, float _y=0.f, float _z=0.f)
	{
		x = _x; y = _y; z = _z;
	}
}; /* Vec3f */

struct Vec2f 
{
	float x,y;
	Vec2f(float _x=0.f, float _y=0.f)
	{
		x = _x; y = _y;
	}
}; /* Vec2f */

struct Tri
{
	Vec3f v[3], n[3];
	Vec2f t[3];
};

int strcharcnt(const char* line, char model)
{
	int result = 0;
	while(*line)
	{
		if(*line == model)
			result++;
		line++;
	}
	return result;
}

inline void writeVec3f(const Vec3f* v, FILE* f)
{
	fwrite((void*)&v->x, 4, 1, f);
	fwrite((void*)&v->y, 4, 1, f);
	fwrite((void*)&v->z, 4, 1, f);
}

inline void writeVec2f(const Vec2f* v, FILE* f)
{
	fwrite((void*)&v->x, 4, 1, f);
	fwrite((void*)&v->y, 4, 1, f);
}

int main(int argc, const char *argv[])
{
	if(argc < 2){
		fprintf(stderr, "ERROR : no file name was given\n");
		return EXIT_FAILURE;
	}

	for(int files=1;files < argc;files++)
	{
		// open the obj file
		FILE* f = fopen(argv[files], "r");
		if(!f){
			fprintf(stderr, "ERROR : the file could not be found\n");
			return EXIT_FAILURE;
		}

		vector<Vec3f> vertices, normals;
		vector<Vec2f> texcoords;
		vector<Tri> tris;

		char line[64];

		while(fgets(line, 64, f))
		{
			if(line[0] == 'v' && line[1] == ' ')
			{
				static float x,y,z;
				sscanf(line, "v %f %f %f",&x,&y,&z);
				vertices.push_back(Vec3f(x,y,z));
			}

			else if(line[0] == 'v' && line[1] == 'n')
			{
				static float x,y,z;
				sscanf(line, "vn %f %f %f",&x,&y,&z);
				normals.push_back(Vec3f(x,y,z));
			}

			else if(line[0] == 'v' && line[1] == 't')
			{
				static float u,v;
				sscanf(line, "vt %f %f",&u,&v);
				texcoords.push_back(Vec2f(u,v));
			}

			else if(line[0] == 'f')
			{
				static int v1, v2, v3, v4;
				static int n1, n2, n3, n4;
				static int t1, t2, t3, t4; 
				static Tri triangle[2];
				if(!normals.size()){
					fprintf(stderr, "ERROR : no normals found\n");
					return EXIT_FAILURE;
				}

				if(!texcoords.size()){
					fprintf(stderr, "ERROR : no texcoords found\n");
					return EXIT_FAILURE;
				}

				// Quad
				if(strcharcnt(line, '/') == 8){
					sscanf(line, "f %d/%d/%d %d/%d/%d %d/%d/%d %d/%d/%d", &v1, &n1, &t1, &v2, &n2, &t2, &v3, &n3, &t3, &v4, &n4, &t4);

					triangle[0].v[0] = vertices[v1 - 1];
					triangle[0].v[1] = vertices[v2 - 1];
					triangle[0].v[2] = vertices[v4 - 1];
					triangle[1].v[0] = vertices[v2 - 1];
					triangle[1].v[1] = vertices[v3 - 1];
					triangle[1].v[2] = vertices[v4 - 1];

					triangle[0].n[0] = normals[n1 - 1];
					triangle[0].n[1] = normals[n2 - 1];
					triangle[0].n[2] = normals[n4 - 1];
					triangle[1].n[0] = normals[n2 - 1];
					triangle[1].n[1] = normals[n3 - 1];
					triangle[1].n[2] = normals[n4 - 1];

					triangle[0].t[0] = texcoords[t1 - 1];
					triangle[0].t[1] = texcoords[t2 - 1];
					triangle[0].t[2] = texcoords[t4 - 1];
					triangle[1].t[0] = texcoords[t2 - 1];
					triangle[1].t[1] = texcoords[t3 - 1];
					triangle[1].t[2] = texcoords[t4 - 1];

					tris.push_back(triangle[0]);
					tris.push_back(triangle[1]);
				}

				// Triangle
				else
				{
					sscanf(line, "f %d/%d/%d %d/%d/%d %d/%d/%d", &v1, &n1, &t1, &v2, &n2, &t2, &v3, &n3, &t3);
					triangle[0].v[0] = vertices[v1 - 1];
					triangle[0].v[1] = vertices[v2 - 1];
					triangle[0].v[2] = vertices[v3 - 1];

					triangle[0].n[0] = normals[n1 - 1];
					triangle[0].n[1] = normals[n2 - 1];
					triangle[0].n[2] = normals[n3 - 1];
					
					triangle[0].t[0] = texcoords[t1 - 1];
					triangle[0].t[1] = texcoords[t2 - 1];
					triangle[0].t[2] = texcoords[t3 - 1];

					tris.push_back(triangle[0]);
				}
			}

		}

		vertices.clear();
		normals.clear();
		texcoords.clear();
		fclose(f);

		// write output file
		char filename[64];
		strcpy(filename, argv[files]);
		char* last = &filename[0];
		char* current = &filename[0];
		while(*current)
		{
			if(*current == '.')
				last = ++current;
			current++;
		}
		
		// extension
		last[0] = 'i'; last[1] = 'm'; last[2] = 'f';

		f = fopen(filename, "wb");
		unsigned int size = tris.size();
		fwrite((void*)&size, 4, 1, f);

		for(unsigned int i=0;i<tris.size();i++)
		{
			writeVec3f(&tris[i].v[0], f);
			writeVec3f(&tris[i].v[1], f);
			writeVec3f(&tris[i].v[2], f);

			writeVec3f(&tris[i].n[0], f);
			writeVec3f(&tris[i].n[1], f);
			writeVec3f(&tris[i].n[2], f);

			writeVec2f(&tris[i].t[0], f);
			writeVec2f(&tris[i].t[1], f);
			writeVec2f(&tris[i].t[2], f);
		}

		fclose(f);
	}
	return 0;
}
